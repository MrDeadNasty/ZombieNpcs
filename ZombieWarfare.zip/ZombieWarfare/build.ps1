# build.ps1  –  packages ZombieNPCs into a Metro-compatible .vmz
# Usage:  .\build.ps1
# Optional:  .\build.ps1 -Install   (also copies to game mods folder)
param(
    [switch]$Install
)

$ModName    = "ZombieNPCs"
$GameMods   = "$env:ProgramFiles(x86)\Steam\steamapps\common\Road to Vostok\mods"
$ZipFile    = "$ModName.zip"
$VmzFile    = "$ModName.vmz"

# Clean old build
if (Test-Path $ZipFile) { Remove-Item $ZipFile }
if (Test-Path $VmzFile) { Remove-Item $VmzFile }

# Pack: mod.txt must be at the archive root
Compress-Archive -Path "mod.txt", "mods" -DestinationPath $ZipFile
Rename-Item $ZipFile $VmzFile

Write-Host "Built $VmzFile" -ForegroundColor Green

if ($Install) {
    if (-not (Test-Path $GameMods)) {
        New-Item -ItemType Directory -Path $GameMods | Out-Null
    }
    Copy-Item $VmzFile $GameMods -Force
    Write-Host "Installed to $GameMods\$VmzFile" -ForegroundColor Cyan
}
