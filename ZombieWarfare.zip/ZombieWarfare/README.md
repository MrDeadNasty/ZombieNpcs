# Zombie NPCs — Road to Vostok Mod
**Version:** 1.0.0  
**Loader:** Metro Mod Loader v3.1+  
**Optional dependency:** Mod Configuration Menu (MCM) by DoinkOink

---

## What it does

Turns a configurable percentage of spawned NPCs into shambling zombie-like threats:

| Feature | Detail |
|---|---|
| **Zombie ratio** | X% of newly spawned NPCs become zombies (configurable) |
| **Max zombie cap** | Hard limit on simultaneous zombies (configurable) |
| **Stagger walk** | Zombies oscillate side-to-side as they move |
| **Grunting** | Zombies vocalise at random intervals (drop audio files in `audio/`) |
| **Horrible aim** | Extra angular spread + a fire delay added to zombie shots |
| **Faction war** | Non-zombie NPCs actively hunt zombie NPCs within alert range |
| **All values** | Fully configurable through MCM in-game, changes apply live |

---

## Requirements

| Mod | Where to get it |
|---|---|
| Metro Mod Loader v3.1+ | [ModWorkshop](https://modworkshop.net/mod/55623) |
| MCM *(optional but recommended)* | [ModWorkshop](https://modworkshop.net/mod/53713) |

> Without MCM the mod still works – all defaults apply and config can be edited
> manually at `%APPDATA%\Road to Vostok\MCM\ZombieNPCs\config.ini`.

---

## Installation

1. Make sure **Metro Mod Loader** is installed (see its page for instructions).  
2. *(Recommended)* Install **MCM** and set its priority to **-100** in the loader
   so it loads before everything else.  
3. Drop **ZombieNPCs.vmz** into:
   ```
   C:\Program Files (x86)\Steam\steamapps\common\Road to Vostok\mods\
   ```
4. Launch the game → the Metro pre-launcher appears → tick **Zombie NPCs** → Launch.

---

## Configuration (MCM)

Open **Settings → MCM → Zombie NPCs** in-game.

### General
| Setting | Default | Description |
|---|---|---|
| Mod Enabled | ✅ | Master toggle |
| Debug Logging | ❌ | Prints verbose info to Godot output |

### Spawn
| Setting | Default | Description |
|---|---|---|
| Zombie Ratio | 0.40 | Fraction of new NPCs turned (0 = none, 1 = all) |
| Max Simultaneous Zombies | 20 | Hard cap (0 = unlimited) |

### Behaviour – Grunting
| Setting | Default | Description |
|---|---|---|
| Grunt Interval Min | 4 s | Minimum gap between vocalisations |
| Grunt Interval Max | 10 s | Maximum gap between vocalisations |

### Behaviour – Movement
| Setting | Default | Description |
|---|---|---|
| Stagger Strength | 0.35 | Side-to-side sway amplitude (0–1) |
| Stagger Speed | 0.55 | Oscillation frequency (0–1) |

### Behaviour – Combat
| Setting | Default | Description |
|---|---|---|
| Zombie Aim Spread | 18 ° | Added random error to zombie shots |
| Zombie Fire Delay | 1.2 s | Extra pause before zombie pulls trigger |

### Faction
| Setting | Default | Description |
|---|---|---|
| Normal NPCs Shoot Zombies | ✅ | Non-zombie NPCs engage zombies on sight |
| NPC Alert Range | 22 m | Distance at which normal NPC notices zombies |

---

## Adding zombie grunt sounds

Place OGG or WAV files inside the `.vmz` at:
```
mods/ZombieMod/audio/grunt1.ogg
mods/ZombieMod/audio/grunt2.ogg
mods/ZombieMod/audio/grunt3.ogg
```
Then uncomment the matching lines in `ZombieComponent.gd → GRUNT_SOUNDS`.

---

## How it works (for modders)

```
mod.txt
  └── autoloads:
        ZombieModConfig (Config.gd)   – MCM registration & config I/O
        ZombieModMain   (Main.gd)     – scene-tree watcher, faction logic

Main.gd
  ├── Connects get_tree().node_added
  ├── _is_npc() – group/class/property heuristics
  ├── random roll → _make_zombie()
  │     └── attaches ZombieComponent as child of NPC node
  └── _do_faction_scan() every 0.5 s
        └── calls set_target(zombie) on nearby normal NPCs

ZombieComponent.gd (per-zombie Node child)
  ├── _tick_stagger()  – offsets velocity each frame
  ├── _tick_grunt()    – fires audio at random intervals
  └── _apply_aim_penalty() – pokes accuracy/spread property
```

### NPC detection

The mod identifies NPC nodes by:
1. Godot group membership (`npc`, `ai`, `enemy`, `guard`, …)
2. Class name containing `NPC`, `Enemy`, `Guard`, `Wanderer`, …
3. Presence of vital properties (`health`, `max_health`, `hp`, …)

If a custom NPC type isn't detected, add its group name to `NPC_GROUPS` in
`Main.gd` or add the node to the `npc` group in your own mod.

### Aim penalty

The mod tries to write to property names `accuracy`, `spread`, `aim_spread`,
`shot_spread`, `weapon_spread`, `base_spread`, `dispersion` on the NPC node
**and** its first-level children (weapon nodes).  If the game updates and
renames these, extend `AIM_PROPS` in `ZombieComponent.gd`.

### Target assignment

Normal NPCs are given a zombie target by calling `set_target(node)` /
`set_enemy(node)` etc.  If none of the known method names match, the mod falls
back to setting properties `target`, `enemy`, `hostile_target`.  Extend
`TARGET_METHODS` / `TARGET_PROPS` in `Main.gd` as needed.

---

## Building the .vmz

A `.vmz` is just a `.zip` renamed.  Pack the following structure:

```
ZombieNPCs.vmz
├── mod.txt
└── mods/
    └── ZombieMod/
        ├── Main.gd
        ├── Config.gd
        ├── ZombieComponent.gd
        └── audio/           (optional – see above)
```

PowerShell one-liner:
```powershell
Compress-Archive -Path mod.txt, mods -DestinationPath ZombieNPCs.zip
Rename-Item ZombieNPCs.zip ZombieNPCs.vmz
```

---

## Compatibility notes

- **Metro Mod Loader 3.0 opt-in model**: `mod.txt` declares both autoloads
  explicitly so no `[hooks]` section is needed for basic autoload injection.
- **MCM**: set MCM priority to **-100** (loads first).  
  ZombieNPCs can use any priority ≥ 0.
- **RTVCoop**: zombie state is per-client; networked sync not included in v1.

---

## License

MIT – do whatever you like, credit appreciated.
