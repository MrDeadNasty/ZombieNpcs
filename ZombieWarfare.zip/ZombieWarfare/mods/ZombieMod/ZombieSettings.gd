extends Resource
class_name ZombieSettings

# General
@export var enabled               : bool  = true
@export var debug_log             : bool  = false

# Zombie spawn
@export var min_zombies           : int   = 3
@export var max_zombies           : int   = 7
@export var zombie_timer_min      : float = 5.0
@export var zombie_timer_max      : float = 15.0
@export var zombie_health_mult    : float = 1.0   # health multiplier for zombie NPCs

# Normal NPC fighters
@export var npc_fight_zombies     : bool  = true
@export var min_npcs              : int   = 2
@export var max_npcs              : int   = 5
@export var npc_timer_min         : float = 8.0
@export var npc_timer_max         : float = 20.0

# Zombie behaviour
@export var grunt_interval_min    : float = 4.0
@export var grunt_interval_max    : float = 10.0
@export var stagger_strength      : float = 0.35
@export var stagger_speed         : float = 0.45
@export var aim_spread            : float = 18.0
@export var aim_fire_delay        : float = 1.2

var mcm_enabled : bool = false
