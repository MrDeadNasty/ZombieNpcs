# ZombieMod/SpawnerHooks.gd
# Hooks into AISpawner.gd to tag NPCs as zombies or fighters on spawn,
# and to set the spawner's spawnLimit/spawnPool from our config so the
# game actually spawns enough NPCs for us to tag.
#
# Key insight from FactionWarfare SpawnerHooks:
#   - spawner.spawnLimit  = how many can be alive at once (vanilla default ~3)
#   - spawner.spawnPool   = reserve pool size (how many total can ever spawn)
#   - spawner.spawnTime   = seconds between spawn ticks (we leave this alone)
#   - The last spawned agent is spawner.agents.get_child(child_count - 1)
#   - Groups are used to count tagged NPCs across all spawners
#   - zm_zombie / zm_fighter meta keys identify tagged NPCs to AIHooks
#
# Spawn decision logic:
#   On every SpawnWanderer/Guard/Hider post-hook:
#     Count live zombies via group "zm_zombies"
#     Count live fighters via group "zm_fighters"
#     If zombie count < min_zombies  → always tag zombie
#     Else if zombie count < max_zombies → 50% chance tag zombie
#     Else if fighter mode on and fighter count < min_npcs → always tag fighter
#     Else if fighter mode on and fighter count < max_npcs → 50% chance tag fighter
#
#   Bosses are never zombified (only fighters or untagged).
extends Node

const ZS := preload("res://mods/ZombieMod/ZombieSettings.tres")

var _lib = null


func register_hooks(lib) -> void:
	_lib = lib
	_lib.hook("aispawner-_ready-post",        _on_spawner_ready_post)
	_lib.hook("aispawner-spawnwanderer-post",  _on_any_spawn_post)
	_lib.hook("aispawner-spawnguard-post",     _on_any_spawn_post)
	_lib.hook("aispawner-spawnhider-post",     _on_any_spawn_post)
	_lib.hook("aispawner-spawnminion-post",    _on_any_spawn_post)
	_lib.hook("aispawner-spawnboss-post",      _on_boss_spawn_post)
	print("[ZombieMod/SpawnerHooks] Registered.")


# ── Spawner _ready post ───────────────────────────────────────────────────────
# Vanilla _ready sets spawnLimit to a small number (typically 3).
# We raise it so the game will spawn enough agents for our tags to work.
func _on_spawner_ready_post() -> void:
	var spawner = _lib._caller
	if not is_instance_valid(spawner): return
	if not ZS.enabled: return

	# Raise the spawner limits to accommodate both zombie and fighter pools.
	# We want at least max_zombies + max_npcs agents able to be alive.
	var needed_limit : int = ZS.max_zombies + ZS.max_npcs + 2  # +2 buffer
	var needed_pool  : int = needed_limit * 4  # generous reserve

	if "spawnLimit" in spawner:
		spawner.spawnLimit = max(spawner.spawnLimit, needed_limit)
	if "spawnPool" in spawner:
		spawner.spawnPool  = max(spawner.spawnPool,  needed_pool)

	_dbg("Spawner ready – spawnLimit=%d spawnPool=%d" % [
		spawner.get("spawnLimit") if "spawnLimit" in spawner else -1,
		spawner.get("spawnPool")  if "spawnPool"  in spawner else -1
	])


# ── Generic spawn post (Wanderer, Guard, Hider, Minion) ───────────────────────
func _on_any_spawn_post() -> void:
	var spawner = _lib._caller
	if not is_instance_valid(spawner): return
	_tag_last_agent(spawner, false)


# ── Boss spawn post ───────────────────────────────────────────────────────────
func _on_boss_spawn_post() -> void:
	var spawner = _lib._caller
	if not is_instance_valid(spawner): return
	_tag_last_agent(spawner, true)  # skip_zombie=true: bosses become fighters only


# ── Core tagging logic ────────────────────────────────────────────────────────
func _tag_last_agent(spawner: Node, skip_zombie: bool) -> void:
	if not ZS.enabled: return

	# Find the agent container. FactionWarfare uses spawner.agents directly.
	var agents_node : Node = null
	if "agents" in spawner and is_instance_valid(spawner.agents):
		agents_node = spawner.agents
	else:
		# Fallback: find a child named "Agents" or similar
		for child in spawner.get_children():
			if child.name.to_lower().begins_with("agent"):
				agents_node = child
				break
	if agents_node == null: return

	var count = agents_node.get_child_count()
	if count == 0: return

	var agent : Node = agents_node.get_child(count - 1)
	if not is_instance_valid(agent): return

	# Skip if already tagged by us
	if agent.has_meta("zm_zombie") or agent.has_meta("zm_fighter"): return

	# Count current live tagged populations via groups
	# get_nodes_in_group returns only valid nodes in the current scene tree
	var zombie_count  : int = get_tree().get_nodes_in_group("zm_zombies").size()
	var fighter_count : int = get_tree().get_nodes_in_group("zm_fighters").size()

	# ── Zombie decision ──────────────────────────────────────────────────────
	if not skip_zombie:
		var want_zombie := false
		if zombie_count < ZS.min_zombies:
			want_zombie = true   # must fill the floor
		elif zombie_count < ZS.max_zombies:
			want_zombie = randf() < 0.5
		if want_zombie:
			_make_zombie(agent)
			return

	# ── Fighter decision ─────────────────────────────────────────────────────
	if ZS.npc_fight_zombies:
		var want_fighter := false
		if fighter_count < ZS.min_npcs:
			want_fighter = true
		elif fighter_count < ZS.max_npcs:
			want_fighter = randf() < 0.5
		if want_fighter:
			_make_fighter(agent)


func _make_zombie(agent: Node) -> void:
	agent.set_meta("zm_zombie", true)
	agent.add_to_group("zm_zombies")
	# Tag with aso_faction="Zombie" so ASO's _aso_hostile() IFC scan
	# and raycast hit code treat all standard factions as hostile toward
	# zombies. ASO reads this meta on every NPC it evaluates for faction war.
	agent.set_meta("aso_faction", "Zombie")
	_dbg("Zombified: %s  (total=%d)" % [
		agent.name,
		get_tree().get_nodes_in_group("zm_zombies").size()
	])


func _make_fighter(agent: Node) -> void:
	agent.set_meta("zm_fighter", true)
	agent.add_to_group("zm_fighters")
	# Derive the NPC's real faction from scene_file_path — same logic ASO uses
	# in _S() and _on_ai_initialize_post(). This means ASO's full IFC system
	# (detection meter, reaction time, personality, rotation limits, ammo,
	# suppression) applies to these NPCs automatically. They will target
	# zombies because _aso_hostile("Guard"/"Bandit"/"Military", "Zombie")
	# returns true via the catch-all branch in _aso_hostile().
	if not agent.has_meta("aso_faction"):
		var p : String = str(agent.scene_file_path).to_lower()
		var faction : String = "Bandit"
		if   "punisher" in p: faction = "Punisher"
		elif "military" in p: faction = "Military"
		elif "guard"    in p: faction = "Guard"
		agent.set_meta("aso_faction", faction)
	_dbg("Fighter NPC: %s faction=%s (total=%d)" % [
		agent.name,
		str(agent.get_meta("aso_faction")),
		get_tree().get_nodes_in_group("zm_fighters").size()
	])


func _dbg(msg: String) -> void:
	if ZS.debug_log: print("[ZombieMod/SpawnerHooks] ", msg)
