# ZombieMod/Config.gd
# Mirrors FactionWarfare's Config.gd pattern exactly:
#   - preload the .tres settings resource
#   - build ConfigFile with all defaults
#   - save on first run, CheckConfigurationHasUpdated on subsequent runs
#   - _on_config_updated(config) receives the full ConfigFile object
#   - RegisterConfiguration passes the callback directly (not a string name)
extends Node

const ZS := preload("res://mods/ZombieMod/ZombieSettings.tres")
var McmHelpers = load("res://ModConfigurationMenu/Scripts/Doink Oink/MCM_Helpers.tres")

const FILE_PATH = "user://MCM/ZombieNPCs"
const MOD_ID    = "ZombieNPCs"

func _ready() -> void:
	var config = ConfigFile.new()

	# ── General ───────────────────────────────────────────────────────────────
	config.set_value("Bool", "enabled", {
		"name"     = "Mod Enabled",
		"tooltip"  = "Master switch. Disables all zombie behaviour when off.",
		"default"  = true,
		"value"    = true,
		"menu_pos" = 1
	})
	config.set_value("Bool", "debug_log", {
		"name"     = "Debug Logging",
		"tooltip"  = "Print verbose debug messages to the Godot output panel.",
		"default"  = false,
		"value"    = false,
		"menu_pos" = 2
	})

	# ── Zombie Spawn ──────────────────────────────────────────────────────────
	config.set_value("Int", "min_zombies", {
		"name"     = "Min Zombies",
		"tooltip"  = "Minimum zombies kept alive at once. The mod tags newly spawned NPCs as zombies until this floor is reached.",
		"default"  = 3,
		"value"    = 3,
		"menu_pos" = 10,
		"minRange" = 0,
		"maxRange" = 50
	})
	config.set_value("Int", "max_zombies", {
		"name"     = "Max Zombies",
		"tooltip"  = "Hard cap on simultaneous zombie NPCs.",
		"default"  = 7,
		"value"    = 7,
		"menu_pos" = 11,
		"minRange" = 0,
		"maxRange" = 50
	})
	config.set_value("Float", "zombie_timer_min", {
		"name"     = "Zombie Spawn Timer Min (s)",
		"tooltip"  = "Minimum seconds between zombie top-up checks.",
		"default"  = 5.0,
		"value"    = 5.0,
		"menu_pos" = 12,
		"minRange" = 1.0,
		"maxRange" = 120.0
	})
	config.set_value("Float", "zombie_timer_max", {
		"name"     = "Zombie Spawn Timer Max (s)",
		"tooltip"  = "Maximum seconds between zombie top-up checks.",
		"default"  = 15.0,
		"value"    = 15.0,
		"menu_pos" = 13,
		"minRange" = 1.0,
		"maxRange" = 120.0
	})
	config.set_value("Float", "zombie_health_mult", {
		"name"     = "Zombie Health Multiplier",
		"tooltip"  = "Multiplies the base health of zombie NPCs. 1.0 = normal, 2.0 = double health.",
		"default"  = 1.0,
		"value"    = 1.0,
		"menu_pos" = 14,
		"minRange" = 0.25,
		"maxRange" = 5.0
	})

	# ── NPC Fighters ──────────────────────────────────────────────────────────
	config.set_value("Bool", "npc_fight_zombies", {
		"name"     = "NPCs Fight Zombies",
		"tooltip"  = "When ON, some spawned NPCs are tagged as fighters. ASO (Armed Enhancement - AI System Overhaul) handles their AI: faction detection, reaction time, personality, ammo, and suppression fire. ASO must be installed.",
		"default"  = true,
		"value"    = true,
		"menu_pos" = 20
	})
	config.set_value("Int", "min_npcs", {
		"name"     = "Min NPC Fighters",
		"tooltip"  = "Minimum normal NPCs kept in the fighter pool.",
		"default"  = 2,
		"value"    = 2,
		"menu_pos" = 21,
		"minRange" = 0,
		"maxRange" = 50
	})
	config.set_value("Int", "max_npcs", {
		"name"     = "Max NPC Fighters",
		"tooltip"  = "Maximum normal NPCs in the fighter pool.",
		"default"  = 5,
		"value"    = 5,
		"menu_pos" = 22,
		"minRange" = 0,
		"maxRange" = 50
	})
	config.set_value("Float", "npc_timer_min", {
		"name"     = "NPC Spawn Timer Min (s)",
		"tooltip"  = "Minimum seconds between NPC fighter top-up checks.",
		"default"  = 8.0,
		"value"    = 8.0,
		"menu_pos" = 23,
		"minRange" = 1.0,
		"maxRange" = 120.0
	})
	config.set_value("Float", "npc_timer_max", {
		"name"     = "NPC Spawn Timer Max (s)",
		"tooltip"  = "Maximum seconds between NPC fighter top-up checks.",
		"default"  = 20.0,
		"value"    = 20.0,
		"menu_pos" = 24,
		"minRange" = 1.0,
		"maxRange" = 120.0
	})

	# ── Zombie Behaviour ──────────────────────────────────────────────────────
	config.set_value("Float", "stagger_strength", {
		"name"     = "Stagger Strength",
		"tooltip"  = "How much zombies yaw/weave side-to-side. 0 = none, 1 = extreme.",
		"default"  = 0.35,
		"value"    = 0.35,
		"menu_pos" = 30,
		"minRange" = 0.0,
		"maxRange" = 1.0
	})
	config.set_value("Float", "stagger_speed", {
		"name"     = "Stagger Speed",
		"tooltip"  = "How fast the stagger oscillates. 0 = slow weave (~1 cycle/3s), 1 = fast wobble (~1 cycle/s).",
		"default"  = 0.45,
		"value"    = 0.45,
		"menu_pos" = 31,
		"minRange" = 0.0,
		"maxRange" = 1.0
	})
	config.set_value("Float", "grunt_interval_min", {
		"name"     = "Grunt Interval Min (s)",
		"tooltip"  = "Minimum seconds between zombie grunt sounds.",
		"default"  = 4.0,
		"value"    = 4.0,
		"menu_pos" = 32,
		"minRange" = 0.5,
		"maxRange" = 30.0
	})
	config.set_value("Float", "grunt_interval_max", {
		"name"     = "Grunt Interval Max (s)",
		"tooltip"  = "Maximum seconds between zombie grunt sounds.",
		"default"  = 10.0,
		"value"    = 10.0,
		"menu_pos" = 33,
		"minRange" = 1.0,
		"maxRange" = 60.0
	})
	config.set_value("Float", "aim_spread", {
		"name"     = "Zombie Aim Spread (degrees)",
		"tooltip"  = "Extra random angular error on zombie shots.",
		"default"  = 18.0,
		"value"    = 18.0,
		"menu_pos" = 34,
		"minRange" = 0.0,
		"maxRange" = 45.0
	})
	config.set_value("Float", "aim_fire_delay", {
		"name"     = "Zombie Fire Delay (s)",
		"tooltip"  = "Extra seconds a zombie waits before pulling the trigger.",
		"default"  = 1.2,
		"value"    = 1.2,
		"menu_pos" = 35,
		"minRange" = 0.0,
		"maxRange" = 5.0
	})

	# ── Save / load ───────────────────────────────────────────────────────────
	if not FileAccess.file_exists(FILE_PATH + "/config.ini"):
		DirAccess.open("user://").make_dir_recursive(FILE_PATH)
		config.save(FILE_PATH + "/config.ini")
	else:
		if McmHelpers != null:
			McmHelpers.CheckConfigurationHasUpdated(MOD_ID, config, FILE_PATH + "/config.ini")
		config.load(FILE_PATH + "/config.ini")

	_on_config_updated(config)

	if McmHelpers != null:
		McmHelpers.RegisterConfiguration(
			MOD_ID,
			"Zombie NPCs",
			FILE_PATH,
			"Zombie NPC behaviour: counts, spawn timers, stagger, aim, health, and NPC fighter squad.",
			{
				"config.ini" = _on_config_updated
			}
		)


func _on_config_updated(config: ConfigFile) -> void:
	ZS.enabled            = config.get_value("Bool",  "enabled",            {"value": true})["value"]
	ZS.debug_log          = config.get_value("Bool",  "debug_log",          {"value": false})["value"]
	ZS.min_zombies        = config.get_value("Int",   "min_zombies",        {"value": 3})["value"]
	ZS.max_zombies        = config.get_value("Int",   "max_zombies",        {"value": 7})["value"]
	ZS.zombie_timer_min   = config.get_value("Float", "zombie_timer_min",   {"value": 5.0})["value"]
	ZS.zombie_timer_max   = config.get_value("Float", "zombie_timer_max",   {"value": 15.0})["value"]
	ZS.zombie_health_mult = config.get_value("Float", "zombie_health_mult", {"value": 1.0})["value"]
	ZS.npc_fight_zombies  = config.get_value("Bool",  "npc_fight_zombies",  {"value": true})["value"]
	ZS.min_npcs           = config.get_value("Int",   "min_npcs",           {"value": 2})["value"]
	ZS.max_npcs           = config.get_value("Int",   "max_npcs",           {"value": 5})["value"]
	ZS.npc_timer_min      = config.get_value("Float", "npc_timer_min",      {"value": 8.0})["value"]
	ZS.npc_timer_max      = config.get_value("Float", "npc_timer_max",      {"value": 20.0})["value"]
	ZS.stagger_strength   = config.get_value("Float", "stagger_strength",   {"value": 0.35})["value"]
	ZS.stagger_speed      = config.get_value("Float", "stagger_speed",      {"value": 0.45})["value"]
	ZS.grunt_interval_min = config.get_value("Float", "grunt_interval_min", {"value": 4.0})["value"]
	ZS.grunt_interval_max = config.get_value("Float", "grunt_interval_max", {"value": 10.0})["value"]
	ZS.aim_spread         = config.get_value("Float", "aim_spread",         {"value": 18.0})["value"]
	ZS.aim_fire_delay     = config.get_value("Float", "aim_fire_delay",     {"value": 1.2})["value"]
	ZS.mcm_enabled        = true
