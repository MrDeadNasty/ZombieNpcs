# ZombieMod/AIHooks.gd
# Hooks into AI.gd for zombie-only behaviour: stagger, aim penalty, health
# multiplier, melee loadout, and fire delay.
#
# Fighter NPC AI is fully delegated to ASO (Armed Enhancement - AI System
# Overhaul, priority 60). We tag fighter NPCs with aso_faction in
# SpawnerHooks so ASO's IFC system handles detection, reaction time,
# personality, rotation, ammo, suppression, and faction targeting automatically.
# We register NO hooks that touch fighter NPCs here.
#
# STAGGER — compounding rotation fix:
#   Store last frame's yaw offset in meta "zm_last_yaw". Each frame:
#     ai.rotation.y = ai.rotation.y - last_yaw + new_yaw
#   Net change is always exactly (new_yaw - last_yaw). Never compounds.
#   freq_hz = lerp(0.3, 1.2, stagger_speed) → default 0.705 Hz = ~1.4s/cycle.
#   MAX_YAW_RAD = 0.18 (~10°) hard ceiling per frame.
extends Node

const ZS := preload("res://mods/ZombieMod/ZombieSettings.tres")

# Maximum yaw offset we will EVER apply per frame (hard ceiling)
const MAX_YAW_RAD : float = 0.18   # ~10 degrees

var _lib = null


func register_hooks(lib) -> void:
	_lib = lib
	# activate-post: health multiplier applied after vanilla sets health
	_lib.hook("ai-activate-post",      _on_activate_post)
	# selectweapon-post: force melee-only loadout on zombie NPCs
	_lib.hook("ai-selectweapon-post",  _on_selectweapon_post)
	# parameters-post: stagger, fire delay, fighter targeting every frame
	_lib.hook("ai-parameters-post",    _on_parameters_post)
	print("[ZombieMod/AIHooks] Registered.")


# ── ai-activate-post ──────────────────────────────────────────────────────────
# Fires after vanilla Activate() sets up the NPC's initial stats.
# Safe to read/write health here because vanilla just assigned it.
func _on_activate_post() -> void:
	var ai = _lib._caller
	if not is_instance_valid(ai): return

	# ── Zombie setup ──────────────────────────────────────────────────────────
	if ai.has_meta("zm_zombie"):
		# Seed oscillator at random phase so all zombies are out of sync
		if not ai.has_meta("zm_stagger_phase"):
			ai.set_meta("zm_stagger_phase", randf_range(0.0, 1.0))
		# Reset last-yaw correction to zero for this activation
		ai.set_meta("zm_last_yaw", 0.0)
		# Speed reduction: store original and write reduced value
		_apply_speed_reduction(ai)
		# Aim penalty
		_apply_aim_penalty(ai)
		# Health multiplier
		if ZS.zombie_health_mult != 1.0:
			_apply_health_mult(ai)



# ── ai-selectweapon-post ──────────────────────────────────────────────────────
# Fires after vanilla SelectWeapon() has already picked and equipped a weapon.
# For zombie NPCs only: find the melee weapon in the weapons container,
# make it the active weapon, and free all ranged weapons.
# Property and method names sourced directly from AInoPistols.vmz / AI.gd.
func _on_selectweapon_post() -> void:
	var ai = _lib._caller
	if not is_instance_valid(ai): return
	if not ai.has_meta("zm_zombie"): return
	if not ZS.enabled: return

	# weapons is the Node container holding all equipped weapon child nodes
	if not "weapons" in ai: return
	var weapons_node : Node = ai.weapons
	if not is_instance_valid(weapons_node): return
	if weapons_node.get_child_count() == 0: return

	# Find a melee weapon among the children
	var melee_weapon : Node = null
	for child in weapons_node.get_children():
		if not is_instance_valid(child): continue
		if not "slotData" in child: continue
		if not is_instance_valid(child.slotData): continue
		if not "itemData" in child.slotData: continue
		var item_data = child.slotData.itemData
		if not is_instance_valid(item_data): continue
		if str(item_data.get("weaponType")) == "Melee":
			melee_weapon = child
			break

	if melee_weapon == null:
		_dbg("No melee weapon found on zombie %s – leaving ranged weapon" % ai.name)
		return

	# Assign the melee weapon as the active weapon (mirrors AInoPistols logic)
	ai.weapon     = melee_weapon
	ai.weaponData = melee_weapon.slotData.itemData
	melee_weapon.show()

	# Free every non-melee weapon so the NPC can't switch back
	for child in weapons_node.get_children():
		if child != melee_weapon:
			child.queue_free()

	# Set animator to rifle rig – melee uses the rifle skeleton in RTV
	if "animator" in ai and is_instance_valid(ai.animator):
		ai.animator["parameters/conditions/Pistol"] = false
		ai.animator["parameters/conditions/Rifle"]  = true

	_dbg("Zombie %s armed with melee only: %s" % [ai.name, ai.weaponData.get("name", "?")])


# ── ai-parameters-post ────────────────────────────────────────────────────────
# Fires after vanilla Parameters(delta) every physics frame for every NPC.
# MUST guard zm_zombie/zm_fighter before doing anything.
func _on_parameters_post(delta: float) -> void:
	var ai = _lib._caller
	if not is_instance_valid(ai): return
	if not ZS.enabled: return

	if ai.has_meta("zm_zombie"):
		_tick_stagger(ai, delta)
		_tick_fire_delay(ai, delta)



# ── Stagger ───────────────────────────────────────────────────────────────────
func _tick_stagger(ai: Node, delta: float) -> void:
	# Only stagger while the NPC is actually moving
	if "velocity" in ai:
		if (ai.velocity as Vector3).length_squared() < 0.04:
			# NPC is standing still — remove any yaw offset we previously added
			var last_yaw : float = ai.get_meta("zm_last_yaw") if ai.has_meta("zm_last_yaw") else 0.0
			if last_yaw != 0.0:
				if ai is Node3D:
					ai.rotation.y -= last_yaw
				ai.set_meta("zm_last_yaw", 0.0)
			return

	# Advance normalised phase [0..1]: freq_hz cycles per second
	# Default speed=0.45 → freq=0.705 Hz → one full sway = ~1.4 seconds
	var freq_hz : float = lerp(0.3, 1.2, float(ZS.stagger_speed))
	var phase   : float = ai.get_meta("zm_stagger_phase") if ai.has_meta("zm_stagger_phase") else 0.0
	phase = fmod(phase + delta * freq_hz, 1.0)
	ai.set_meta("zm_stagger_phase", phase)

	# New yaw offset this frame
	var new_yaw : float = sin(phase * TAU) * float(ZS.stagger_strength) * MAX_YAW_RAD
	var last_yaw : float = ai.get_meta("zm_last_yaw") if ai.has_meta("zm_last_yaw") else 0.0

	# Apply: undo last frame's offset, add this frame's offset
	# This never compounds — net change is always (new_yaw - last_yaw)
	if ai is Node3D:
		ai.rotation.y = ai.rotation.y - last_yaw + new_yaw
	ai.set_meta("zm_last_yaw", new_yaw)


# ── Fire delay ────────────────────────────────────────────────────────────────
# Suppress zombie firing by pushing fireTime back up while delay is pending.
func _tick_fire_delay(ai: Node, delta: float) -> void:
	if not ai.has_meta("zm_fire_pending"): return
	if not ai.get_meta("zm_fire_pending"): return

	var acc : float = ai.get_meta("zm_fire_delay") - delta
	if acc <= 0.0:
		ai.set_meta("zm_fire_pending", false)
		ai.set_meta("zm_fire_delay",   0.0)
	else:
		ai.set_meta("zm_fire_delay", acc)
		# Push fireTime positive so vanilla doesn't fire yet
		if "fireTime" in ai and float(ai.fireTime) <= 0.0:
			ai.fireTime = acc



# ── One-time setup helpers ────────────────────────────────────────────────────
func _apply_speed_reduction(ai: Node) -> void:
	if ai.has_meta("zm_speed_applied"): return
	const SPEED_PROPS := ["move_speed", "walk_speed", "speed", "max_speed",
	                      "movement_speed", "nav_speed", "movementSpeed"]
	for prop in SPEED_PROPS:
		if prop in ai:
			var orig : float = float(ai.get(prop))
			ai.set(prop, orig * 0.55)
			ai.set_meta("zm_orig_speed", orig)
			ai.set_meta("zm_speed_prop", prop)
			break
	ai.set_meta("zm_speed_applied", true)


func _apply_aim_penalty(ai: Node) -> void:
	if ai.has_meta("zm_aim_applied"): return
	const AIM_PROPS := ["accuracy", "spread", "aim_spread", "shot_spread",
	                    "weapon_spread", "base_spread", "dispersion"]
	# Check NPC node first, then first-level children (weapon nodes)
	var targets : Array = [ai] + ai.get_children()
	for node in targets:
		for prop in AIM_PROPS:
			if prop in node:
				var orig : float = float(node.get(prop))
				node.set(prop, orig + deg_to_rad(ZS.aim_spread))
				ai.set_meta("zm_aim_applied", true)
				return
	ai.set_meta("zm_aim_applied", true)  # mark even if no prop found


func _apply_health_mult(ai: Node) -> void:
	if ai.has_meta("zm_health_applied"): return
	const HEALTH_PROPS := ["health", "maxHealth", "max_health", "hitpoints",
	                       "currentHealth", "current_health"]
	for prop in HEALTH_PROPS:
		if prop in ai:
			var orig : float = float(ai.get(prop))
			ai.set(prop, orig * ZS.zombie_health_mult)
			ai.set_meta("zm_health_applied", true)
			return
	ai.set_meta("zm_health_applied", true)


func _dbg(msg: String) -> void:
	if ZS.debug_log: print("[ZombieMod/AIHooks] ", msg)
