# ZombieMod/Main.gd
# Autoload entry point. Priority 70 – loads after ASO (priority 60).
# Warns at startup if ASO is not installed.
extends Node

const _AIHooksScript      := preload("res://mods/ZombieMod/AIHooks.gd")
const _SpawnerHooksScript := preload("res://mods/ZombieMod/SpawnerHooks.gd")

var _ai_hooks      : Node = null
var _spawner_hooks : Node = null


func _ready() -> void:
	name = "ZombieModMain"

	_ai_hooks      = _AIHooksScript.new()
	_ai_hooks.name = "ZombieAIHooks"
	add_child(_ai_hooks)

	_spawner_hooks      = _SpawnerHooksScript.new()
	_spawner_hooks.name = "ZombieSpawnerHooks"
	add_child(_spawner_hooks)

	if not Engine.has_meta("RTVModLib"):
		push_warning("[ZombieMod] RTVModLib not found. Is Metro Mod Loader installed?")
		return

	var lib = Engine.get_meta("RTVModLib")
	if lib._is_ready:
		_register_all_hooks(lib)
	else:
		lib.frameworks_ready.connect(_register_all_hooks.bind(lib))


func _register_all_hooks(lib) -> void:
	_ai_hooks.register_hooks(lib)
	_spawner_hooks.register_hooks(lib)

	# Warn if ASO is not loaded – fighter NPCs won't have proper AI without it
	if not get_node_or_null("/root/ASO"):
		push_warning("[ZombieMod] ASO (Armed Enhancement - AI System Overhaul) not found. " +
			"Fighter NPCs will spawn but won't have enhanced AI or faction targeting. " +
			"Install ASO from ModWorkshop ID 56583.")
	else:
		print("[ZombieMod] ASO detected – fighter NPCs will use full ASO AI.")

	print("[ZombieMod] v4.0.0 ready.")
